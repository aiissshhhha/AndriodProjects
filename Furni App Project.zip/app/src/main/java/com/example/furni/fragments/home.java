package com.example.furni.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.furni.Adapters.FirestoreUtils;
import com.example.furni.Adapters.Products;
import com.example.furni.Adapters.category_adapter;
import com.example.furni.Adapters.data_uploader;
import com.example.furni.CategoryProductsActivity;
import com.example.furni.Login;
import com.example.furni.R;
import com.example.furni.SearchActivity;
import com.example.furni.data_fetcher;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class home extends Fragment implements com.example.furni.Adapters.category_adapter.OnCartButtonClickListener,category_adapter.OnCardClickListener,category_adapter.OnWishButtonClickListener{
    private View v;
    private RecyclerView recyclerView;
    private RecyclerView category_recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    EditText searchbar;
    private List<Products> combined = new ArrayList<>();
    private category_adapter category_adapter;
    com.example.furni.Adapters.data_uploader data_uploader = new data_uploader();
    ProgressBar progressBar;
    TextView name, chair,bed,sofa;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_home, container, false);
        data_fetcher data = new data_fetcher();

        name= v.findViewById(R.id.name);
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        if (guest){
            name.setText("Guest");
        }else {
            fetchUserName();
        }

        // Set up RecyclerView and adapter
        chair = v.findViewById(R.id.chair);
        bed = v.findViewById(R.id.bed);
        sofa = v.findViewById(R.id.sofa);
        recyclerView = v.findViewById(R.id.product_recycler_view);
        layoutManager = new GridLayoutManager(getActivity(), 2);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setLayoutManager(layoutManager);
        searchbar = v.findViewById(R.id.searchbar);
        progressBar = v.findViewById(R.id.progressBar3);
        progressBar.setVisibility(View.GONE);

        // Fetch initial data and populate RecyclerView
        data.fetchPopularata().thenAccept(combinedList -> {
            combined.addAll(combinedList);
            // Randomize the combinedList
            Collections.shuffle(combined);
            Collections.shuffle(combined);
            progressBar.setVisibility(View.GONE);
            category_adapter = new category_adapter(combined);
            recyclerView.setAdapter(category_adapter);
            category_adapter.setOnCartButtonClickListener(this);
            category_adapter.setOnCardClickListener(this);
            category_adapter.setOnWishButtonClickListener(this);
        }).exceptionally(throwable -> {
            Log.e("getData", "Error fetching data", throwable);
            return null;
        });

        bed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), CategoryProductsActivity.class);
                i.putExtra("cat","Beds");
                startActivity(i);
            }
        });

        chair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), CategoryProductsActivity.class);
                i.putExtra("cat","Chairs");
                startActivity(i);
            }
        });

        sofa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), CategoryProductsActivity.class);
                i.putExtra("cat","Sofas");
                startActivity(i);
            }
        });

        searchbar.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                    String query = searchbar.getText().toString();

                    Intent i = new Intent(getActivity(), SearchActivity.class);
                    i.putExtra("query", query);
                    startActivity(i);

                    return true;
                }
                return false;
            }
        });

        // Inflate the layout for this fragment
        return v;
    }

    private void fetchUserName() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Get the current user's email
        FirestoreUtils firestoreUtils = new FirestoreUtils();
        String userEmail = firestoreUtils.getCurrentUserEmail();

        // Create a reference to the user document in the "users" collection
        DocumentReference userDocRef = db.collection("users").document(userEmail);

        // Fetch the user data
        userDocRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    // Get the user's name from the document
                    String userName = document.getString("name");

                    // Do something with the user's name (e.g., display it)
                    Log.d("Firestore", "User Name: " + userName);
                    name.setText(userName);
                } else {
                    Log.d("Firestore", "No such document");
                }
            } else {
                Log.d("Firestore", "Error getting user document: ", task.getException());
            }
        });
    }


    @Override
    public void onCartButtonClick(int position, String name, String imageUrl, String price, String desc) {
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean s1 = sh.getBoolean("guest", false);
        data_uploader.addToCart(desc,imageUrl,name,price,requireActivity(),s1);
        Log.d("data",name+"\n"+imageUrl+"\n"+price);
    }

    @Override
    public void onCardClick(int position,String category, String name, String url,String price, String description) {
        if(category.equals("laptops")||category.equals("shoes")||category.equals("kitchen")||category.equals("shirts")){
            Intent i = new Intent(getActivity(), Login.class);
            i.putExtra("name",name);
            i.putExtra("price",price);
            i.putExtra("url",url);
            i.putExtra("desc",description);
            startActivity(i);
        }

    }

    @Override
    public void OnWishButtonClick(int position, String name, String imageUrl, String price,String desc) {
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        data_uploader.addToWishlist(desc,imageUrl,name,price,requireActivity(),guest);
        }
    }