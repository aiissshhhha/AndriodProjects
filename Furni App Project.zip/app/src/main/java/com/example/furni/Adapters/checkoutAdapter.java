package com.example.furni.Adapters;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.furni.R;

import java.util.List;

public class checkoutAdapter extends RecyclerView.Adapter<checkoutAdapter.checkoutViewHolder>{
    List<checkoutProducts> productsList;

    public checkoutAdapter(List<checkoutProducts> productsList) {
        this.productsList = productsList;
    }
    @NonNull
    @Override
    public checkoutAdapter.checkoutViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_checkout, parent, false);
        return new checkoutAdapter.checkoutViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull checkoutAdapter.checkoutViewHolder holder, int position) {
        checkoutProducts product = productsList.get(position);

        // Retrieve the data from the product object
        String name = product.getName();
        String price = "£ "+product.getPrice();
        Log.e("from check out ","name: "+name+" price: "+price);


        // Set the data to the corresponding views in the ViewHolder
        holder.name.setText(name);
        holder.price.setText(price);
    }

    @Override
    public int getItemCount() {
        return productsList.size();
    }
    public void setProductsList(List<checkoutProducts> productsList) {
        this.productsList = productsList;
        notifyDataSetChanged();
    }
    public class checkoutViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView price;

        public checkoutViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            price = itemView.findViewById(R.id.price);


        }
    }
}
