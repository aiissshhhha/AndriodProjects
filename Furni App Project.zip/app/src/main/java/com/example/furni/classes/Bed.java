package com.example.furni.classes;

public class Bed {
    private String title;
    private String image;
    private String desc;
    private String price;

    // Constructors, getters, and setters

    // Required empty constructor for Firestore
    public Bed() {
    }

    public Bed(String title, String image, String desc, String price) {
        this.title = title;
        this.image = image;
        this.desc = desc;
        this.price = price;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getImage() {
        return image;
    }

    public String getDesc() {
        return desc;
    }

    public String getPrice() {
        return price;
    }

    // Setters (if needed)
    public void setTitle(String title) {
        this.title = title;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}