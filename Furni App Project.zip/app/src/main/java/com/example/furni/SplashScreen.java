package com.example.furni;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.FirebaseApp;

public class SplashScreen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        FirebaseApp.initializeApp(this);
    }

    public void gotologin(View v){
        SharedPreferences sh = getSharedPreferences("guest", MODE_PRIVATE);
        boolean s1 = sh.getBoolean("guest", false);
        if(s1){

            Intent gotohomescreen = new Intent(SplashScreen.this, HomeScreen.class);
            startActivity(gotohomescreen);
        }else{
            Intent gotologinscreen = new Intent(SplashScreen.this, Login.class);
            startActivity(gotologinscreen);
        }

    }
}