package com.example.furni;

import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.furni.Adapters.FirestoreUtils;
import com.example.furni.Adapters.Products;
import com.example.furni.classes.Bed;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class data_fetcher {
    private static final String TAG = "FirestoreHelper";
    public CompletableFuture<List<Products>> fetchPopularata() {
        CompletableFuture<List<Products>> combinedFuture = new CompletableFuture<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("popularProducts")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<Bed> bedList = new ArrayList<>();

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            // Retrieve values from each document
                            String title = document.getString("title");
                            String image = document.getString("image");
                            String desc = document.getString("desc");
                            String price = document.getString("price");

                            // Create a Bed object with the retrieved values
                            Bed bed = new Bed(title, image, desc, price);
                            bedList.add(bed);
                        }

                        // Convert the List<Bed> to List<Products>
                        List<Products> productList = convertToProductsList(bedList,"popular");

                        // Complete the CompletableFuture with the productList
                        combinedFuture.complete(productList);
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());

                        // Complete the CompletableFuture exceptionally if there's an error
                        combinedFuture.completeExceptionally(task.getException());
                    }
                });

        return combinedFuture;
    }

    public CompletableFuture<List<Products>> fetchbedsdata() {
        CompletableFuture<List<Products>> combinedFuture = new CompletableFuture<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("beds")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<Bed> bedList = new ArrayList<>();

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            // Retrieve values from each document
                            String title = document.getString("title");
                            String image = document.getString("image");
                            String desc = document.getString("desc");
                            String price = document.getString("price");

                            // Create a Bed object with the retrieved values
                            Bed bed = new Bed(title, image, desc, price);
                            bedList.add(bed);
                        }

                        // Convert the List<Bed> to List<Products>
                        List<Products> productList = convertToProductsList(bedList,"beds");

                        // Complete the CompletableFuture with the productList
                        combinedFuture.complete(productList);
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());

                        // Complete the CompletableFuture exceptionally if there's an error
                        combinedFuture.completeExceptionally(task.getException());
                    }
                });

        return combinedFuture;
    }

    public CompletableFuture<List<Products>> fetchchairsdata() {
        CompletableFuture<List<Products>> combinedFuture = new CompletableFuture<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("chairs")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<Bed> bedList = new ArrayList<>();

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            // Retrieve values from each document
                            String title = document.getString("title");
                            String image = document.getString("image");
                            String desc = document.getString("desc");
                            String price = document.getString("price");

                            // Create a Bed object with the retrieved values
                            Bed bed = new Bed(title, image, desc, price);
                            bedList.add(bed);
                        }

                        // Convert the List<Bed> to List<Products>
                        List<Products> productList = convertToProductsList(bedList,"chairs");

                        // Complete the CompletableFuture with the productList
                        combinedFuture.complete(productList);
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());

                        // Complete the CompletableFuture exceptionally if there's an error
                        combinedFuture.completeExceptionally(task.getException());
                    }
                });

        return combinedFuture;
    }

    public CompletableFuture<List<Products>> fetchsofasdata() {
        CompletableFuture<List<Products>> combinedFuture = new CompletableFuture<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("sofas")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<Bed> bedList = new ArrayList<>();

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            // Retrieve values from each document
                            String title = document.getString("title");
                            String image = document.getString("image");
                            String desc = document.getString("desc");
                            String price = document.getString("price");

                            // Create a Bed object with the retrieved values
                            Bed bed = new Bed(title, image, desc, price);
                            bedList.add(bed);
                        }

                        // Convert the List<Bed> to List<Products>
                        List<Products> productList = convertToProductsList(bedList,"sofas");

                        // Complete the CompletableFuture with the productList
                        combinedFuture.complete(productList);
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());

                        // Complete the CompletableFuture exceptionally if there's an error
                        combinedFuture.completeExceptionally(task.getException());
                    }
                });

        return combinedFuture;
    }

    private List<Products> convertToProductsList(List<Bed> bedList,String cat) {
        List<Products> productList = new ArrayList<>();

        for (Bed bed : bedList) {
            Products product = new Products(bed.getImage(), bed.getTitle(), bed.getPrice(), cat, bed.getDesc());
            // Assuming "Bed" is the default category for products fetched from the "beds" collection
            productList.add(product);
        }

        return productList;
    }


    // Do something with the retrieved data, such as displaying it in your app
    public static void processBedsData(List<Bed> bedList) {
        // Implement your logic here
        for (Bed bed : bedList) {
            // Access bed.getTitle(), bed.getImage(), bed.getDesc(), bed.getPrice() for each bed
            Log.d(TAG, "Title: " + bed.getTitle());
            Log.d(TAG, "Image: " + bed.getImage());
            Log.d(TAG, "Description: " + bed.getDesc());
            Log.d(TAG, "Price: " + bed.getPrice());
            Log.d(TAG, "----------------------");
        }
    }
}
