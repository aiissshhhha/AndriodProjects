package com.example.furni;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class Payment extends AppCompatActivity {
    TextView total_amount;
    TextView card;
    TextView cod;
    ImageButton back;
    ConstraintLayout card_layout, cod_layout;
    TextView pay, cod_pay;
    Button ok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Intent i = getIntent();
        String total = i.getStringExtra("total");

        pay = findViewById(R.id.pay);
        cod_pay = findViewById(R.id.cod_order);
        back = findViewById(R.id.backbtn);
        total_amount = findViewById(R.id.amount1);
        card = findViewById(R.id.card_method);
        cod = findViewById(R.id.cod_method);
        card_layout = findViewById(R.id.card_layout);
        cod_layout = findViewById(R.id.cod_layout);
        Dialog dialog = new Dialog(Payment.this);
        dialog.setContentView(R.layout.custom_dialog_layout);
        ok = dialog.findViewById(R.id.ok_btn);

        total_amount.setText("£ "+total);

        //for back navigation (back traces the intent stack)
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                finish();
            }
        });

        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                card_layout.setVisibility(View.VISIBLE);
                cod_layout.setVisibility(View.GONE);
            }
        });

        cod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                card_layout.setVisibility(View.GONE);
                cod_layout.setVisibility(View.VISIBLE);
            }
        });

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
            }
        });

        cod_pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}