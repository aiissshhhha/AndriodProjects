package com.example.furni.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.furni.Adapters.FirestoreUtils;
import com.example.furni.Adapters.Products;
import com.example.furni.Adapters.checkoutProducts;
import com.example.furni.EditProfile;
import com.example.furni.Login;
import com.example.furni.R;
import com.example.furni.Register;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class user_profile extends Fragment {
    View v;
    TextView name1,email1,phone1, register_here, login;
    Button edit, logout;
    CardView user_card,guest_card;
    ImageView userimage;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_user_profile, container, false);
        user_card = v.findViewById(R.id.user_card);
        userimage = v.findViewById(R.id.user_image);
        guest_card = v.findViewById(R.id.guest_card);

        SharedPreferences sh = getContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        if (guest){
            user_card.setVisibility(View.GONE);
            userimage.setVisibility(View.GONE);
            guest_card.setVisibility(View.VISIBLE);
            register_here = v.findViewById(R.id.register_here);
            login = v.findViewById(R.id.login);
            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), Login.class);
                    startActivity(intent);
                }
            });
            register_here.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), Register.class);
                    startActivity(intent);
                }
            });
        }else {
            user_card.setVisibility(View.VISIBLE);
            userimage.setVisibility(View.VISIBLE);
            guest_card.setVisibility(View.GONE);
            name1 = v.findViewById(R.id.name);
            email1 = v.findViewById(R.id.email);
            phone1 = v.findViewById(R.id.phone);
            logout = v.findViewById(R.id.log_out_btn);
            edit = v.findViewById(R.id.edit_btn);
            FirebaseAuth mAuth = FirebaseAuth.getInstance();

            fetchUserData();
            logout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Sign out the user
                    mAuth.signOut();
                    Intent intent = new Intent(getActivity(), Login.class);
                    startActivity(intent);
                    getActivity().finish();
                }
            });

            edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), EditProfile.class);
                    startActivity(intent);
                }
            });
        }

        return v;
    }

    private void fetchUserData() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Get the current user's email
        FirestoreUtils firestoreUtils = new FirestoreUtils();
        String userEmail = firestoreUtils.getCurrentUserEmail();

        // Create a reference to the user document in the "users" collection
        DocumentReference userDocRef = db.collection("users").document(userEmail);

        // Fetch the user data
        userDocRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    // Get the user's name and phone from the document
                    String userName = document.getString("name");
                    String userPhone = document.getString("phone");

                    // Do something with the user's name and phone (e.g., display them)
                    name1.setText(userName);
                    email1.setText(userEmail);
                    phone1.setText(userPhone);
                    Log.d("Firestore", "User Name: " + userName);
                    Log.d("Firestore", "User Phone: " + userPhone);
                } else {
                    Log.d("Firestore", "No such document");
                }
            } else {
                Log.d("Firestore", "Error getting user document: ", task.getException());
            }
        });
    }

}