package com.example.furni;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.example.furni.Adapters.FirestoreUtils;
import com.example.furni.fragments.cart;
import com.example.furni.fragments.home;
import com.example.furni.fragments.wishlist;
import com.example.furni.fragments.user_profile;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class HomeScreen extends AppCompatActivity {
    FragmentManager fmanager;
    private MeowBottomNavigation bottomNavigation;
    Boolean checkintent= false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        Intent i = getIntent();
        String check = i.getStringExtra("check");

        if(check!=null&&check.equals("true")){
            checkintent =true;
        }

        if(!checkintent){
            listenForProductChanges();
            listenForwishlistChanges();
        }

        fmanager = getSupportFragmentManager();
        bottomNavigation = findViewById(R.id.bottomNavigation);

        bottomNavigation.add(new MeowBottomNavigation.Model(1, R.drawable.ic_home));
        bottomNavigation.add(new MeowBottomNavigation.Model(2, R.drawable.ic_cart));
        bottomNavigation.add(new MeowBottomNavigation.Model(3, R.drawable.ic_star));
        bottomNavigation.add(new MeowBottomNavigation.Model(4, R.drawable.ic_person));

        // Show the home fragment by default
        bottomNavigation.show(1, true);
        replace(new home());

        // Set onClickMenuListener to handle navigation between fragments
        bottomNavigation.setOnClickMenuListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                switch (model.getId()) {
                    case 1:
                        replace(new home());
                        break;
                    case 2:
                        replace(new cart());
                        break;
                    case 3:
                        replace(new wishlist());
                        break;
                    case 4:
                        replace(new user_profile());
                        break;
                }
                return null;
            }
        });

        bottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                switch (model.getId()){
                    case 1:
                        break;
                }
                return null;
            }
        });
        bottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                switch (model.getId()){
                    case 2:

                        break;
                }
                return null;
            }
        });
        bottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                switch (model.getId()){
                    case 3:

                        break;
                }
                return null;
            }
        });
        bottomNavigation.setOnShowListener(new Function1<MeowBottomNavigation.Model, Unit>() {
            @Override
            public Unit invoke(MeowBottomNavigation.Model model) {
                switch (model.getId()){
                    case 4:

                        break;
                }
                return null;
            }
        });
    }

    public void replace(Fragment frag){
        Log.d("warning","hey this is fragment call");
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.frame,frag);
        ft.commit();
    }

    public void listenForProductChanges() {
        String documentName = "";

        FirestoreUtils firestoreUtils = new FirestoreUtils();
        String email ;

        SharedPreferences sh = getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        if (guest){
            SharedPreferences guestIdPref = getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            documentName=id;
        }else {
            email = firestoreUtils.getCurrentUserEmail();
            documentName = email;
        }

        // Replace "products" with the actual subcollection name within the "cart" collection
        CollectionReference productsRef = FirebaseFirestore.getInstance()
                .collection("cart")
                .document(documentName)
                .collection("Products");

        // Add a snapshot listener to the "products" subcollection reference
        productsRef.addSnapshotListener((queryDocumentSnapshots, e) -> {
            if (e != null) {
                Log.e("Firestore", "Listen failed: " + e);
                return;
            }

            if (queryDocumentSnapshots != null) {
                // Count the number of documents in the "products" subcollection
                int count = queryDocumentSnapshots.size();

                badgeCounter(String.valueOf(count));
                // Now you have the count, you can use it as needed
                Log.d("Firestore", "Number of documents in products collection: " + count);
                // Save the count in a variable or use it for your desired functionality
            } else {
                Log.d("Firestore", "Current data: null");
            }
        });
    }

    public void listenForwishlistChanges() {
        String documentName = "";

        FirestoreUtils firestoreUtils = new FirestoreUtils();
        String email ;

        SharedPreferences sh = getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        if (guest){
            SharedPreferences guestIdPref = getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            documentName=id;
        }else {
            email = firestoreUtils.getCurrentUserEmail();
            documentName = email;
        }

        // Replace "products" with the actual subcollection name within the "cart" collection
        CollectionReference productsRef = FirebaseFirestore.getInstance()
                .collection("wishlist")
                .document(documentName)
                .collection("Products");

        // Add a snapshot listener to the "products" subcollection reference
        productsRef.addSnapshotListener((queryDocumentSnapshots, e) -> {
            if (e != null) {
                Log.e("Firestore", "Listen failed: " + e);
                return;
            }

            if (queryDocumentSnapshots != null) {
                // Count the number of documents in the "products" subcollection
                int count = queryDocumentSnapshots.size();

                wishlistbadgeCounter(String.valueOf(count));
                // Now you have the count, you can use it as needed
                Log.d("Firestore", "Number of documents in products collection: " + count);
                // Save the count in a variable or use it for your desired functionality
            } else {
                Log.d("Firestore", "Current data: null");
            }
        });
    }

    public void badgeCounter(String value)
    {
        bottomNavigation.setCount(2, value);
    }

    public void wishlistbadgeCounter(String value)
    {
        bottomNavigation.setCount(3, value);
    }
}