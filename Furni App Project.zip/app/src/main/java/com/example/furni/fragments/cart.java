package com.example.furni.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.furni.Adapters.CartAdapter;
import com.example.furni.Adapters.FirestoreUtils;
import com.example.furni.Adapters.Products;
import com.example.furni.Adapters.checkoutAdapter;
import com.example.furni.Adapters.checkoutProducts;
import com.example.furni.Payment;
import com.example.furni.R;
import com.example.furni.Register;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class cart extends Fragment implements CartAdapter.OnRemoveButtonClickListener{
    View v;
    TextView total;
    RecyclerView recyclerView;
    RecyclerView checkoutrecyclerView;
    String total_price;
    int t_price;
    Button checkout;
    private FirebaseFirestore firestore;
    private CartAdapter cart_adapter;
    private checkoutAdapter checkoutAdapter;
    TextView empty;
    TextView empty1;
    Button register;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_cart, container, false);
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.custom_dialog_layout_guest_cart);
        register = dialog.findViewById(R.id.register_btn);
        empty = v.findViewById(R.id.empty);
        empty1 = v.findViewById(R.id.empty1);
        firestore = FirebaseFirestore.getInstance();
        total = v.findViewById(R.id.amount1);
        checkout = v.findViewById(R.id.checkout_btn);

        recyclerView = v.findViewById(R.id.cart_recycler_view);
        checkoutrecyclerView = v.findViewById(R.id.amount_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        checkoutrecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        cart_adapter = new CartAdapter(new ArrayList<>());
        checkoutAdapter =new checkoutAdapter(new ArrayList<>());
        recyclerView.setAdapter(cart_adapter);
        checkoutrecyclerView.setAdapter(checkoutAdapter);
        cart_adapter.setOnRemoveButtonClickListener(this);

        fetchProductsFromFirestore("main");

        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sh = getContext().getSharedPreferences("guest", MODE_PRIVATE);
                boolean guest = sh.getBoolean("guest", false);
                if (guest){
                    dialog.show();
                }
                else {
                    if(t_price==0){
                        Toast.makeText(getActivity(), "No items in cart", Toast.LENGTH_SHORT).show();
                    }else {
                        Intent i = new Intent(getContext(), Payment.class);
                        i.putExtra("total",total_price);
                        startActivity(i);
                    }
                }
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent i = new Intent(getContext(), Register.class);
                startActivity(i);
            }
        });
        return v;
    }


    private void fetchProductsFromFirestore(String call) {
        String documentName = "";
        String email;
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        if (guest){
            SharedPreferences guestIdPref = requireContext().getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            documentName=id;
        }else {
            FirestoreUtils firestoreUtils = new FirestoreUtils();
            email = firestoreUtils.getCurrentUserEmail();
            documentName = email;
        }

        firestore.collection("cart")
                .document(documentName)
                .collection("Products")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<Products> productList = new ArrayList<>();
                        List<checkoutProducts> productList1 = new ArrayList<>();

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String imageUrl = document.getString("imageUrl");
                            String name = document.getString("name");
                            String price = document.getString("price");
                            String desc = document.getString("desc");
                            String cat = document.getString("category");

                            if(call=="main"){
                                t_price = t_price+ Integer.parseInt( price);
                            }

                            Products product = new Products(imageUrl, name, price,cat, desc);
                            checkoutProducts product1 = new checkoutProducts(name, price);

                            productList.add(product);
                            productList1.add(product1);
                        }
                        total_price = String.valueOf(t_price);
                        total.setText("£ "+total_price);
                        checkoutAdapter.setProductsList(productList1);
                        cart_adapter.setProductsList(productList);
                        if(productList.isEmpty()){
                            empty.setVisibility(View.VISIBLE);
                            empty.setText("Cart is Empty");
                            empty1.setVisibility(View.VISIBLE);
                            empty1.setText("Cart is Empty");
                        }
                    } else {
                        Log.d("Firestore", "Error getting products: ", task.getException());
                    }
                });
    }

    @Override
    public void onRemoveButtonClick(int position, String name, String imageUrl, String price, String desc) {
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirestoreUtils email_getter = new FirestoreUtils();
        String documentName = name;
        String userEmail ="";
        if (guest) {
            SharedPreferences guestIdPref = requireContext().getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            userEmail=id;
        }
        else {
            userEmail = email_getter.getCurrentUserEmail();
        }

            documentName = name;

            firestore.collection("cart")
                    .document(userEmail)
                    .collection("Products")
                    .document(documentName)
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        // Document successfully deleted
                        Toast.makeText(getActivity(), "Removed Item", Toast.LENGTH_SHORT).show();
                        Log.e("price","t_price before remove: "+t_price);
                        String priceWithoutPoundSign = price.replace("£", "").trim();
                        t_price = t_price - Integer.parseInt(priceWithoutPoundSign);
                        Log.e("price","t_price after remove: "+t_price);
                        total_price = String.valueOf(t_price);
                        total.setText("£ "+total_price);
                        Log.e("price","t_price now: "+t_price);
                        // Refresh the fragment by fetching the updated list of products
                        fetchProductsFromFirestore("refresh");
                    })
                    .addOnFailureListener(e -> {
                        // An error occurred while deleting the document
                        Toast.makeText(getActivity(), "Error removing Item", Toast.LENGTH_SHORT).show();
                    });

    }
}