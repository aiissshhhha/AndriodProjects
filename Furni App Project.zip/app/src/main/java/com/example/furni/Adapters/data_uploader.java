package com.example.furni.Adapters;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class data_uploader {

    private FirebaseFirestore db;
    FirestoreUtils email_getter = new FirestoreUtils();

    public void addToCart(String desc, String Image, String Name, String Price, Activity ac, boolean guest) {
        String email = "";
        if (guest) {
            SharedPreferences guestIdPref = ac.getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            email = id;
            Log.e("email","guest id "+email);
        } else {
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                email = currentUser.getEmail();
            }
        }

        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();

            // Create a reference to the "cart" collection
            CollectionReference cartCollectionRef = db.collection("cart");

            // Create a document reference with the user's email as the document name
            DocumentReference userCartDocRef = cartCollectionRef.document(email);

            // Create a reference to the "Products" collection within the user's cart document
            CollectionReference productsCollectionRef = userCartDocRef.collection("Products");

            // Create a document reference with the product name as the document name
            DocumentReference productDocRef = productsCollectionRef.document(Name);

            // Save the data in Firestore
            String productName = Name;
            String imageUrl = Image;
            String price = Price;

            // Create a map to store the product data
            Map<String, Object> productData = new HashMap<>();
            productData.put("imageUrl", imageUrl);
            productData.put("price", price);
            productData.put("name", productName);
            productData.put("desc",desc);

            // Set the product data in the Firestore document
            productDocRef.set(productData)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d("entry", "entry successful");
                            Toast.makeText(ac, "Item added to cart!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("entry", "entry unsuccessful", e);
                        }
                    });
        }catch (Exception e){
            Log.e("phudu",e.toString());
        }


    }

    public void addToWishlist(String desc,String Image, String Name, String Price, Activity ac, boolean guest) {
        String email = "";
        if (guest) {
            SharedPreferences guestIdPref = ac.getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            email = id;
            Log.e("email","guest id "+email);
        } else {
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                email = currentUser.getEmail();
            }
        }

        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();

            // Create a reference to the "cart" collection
            CollectionReference cartCollectionRef = db.collection("wishlist");

            // Create a document reference with the user's email as the document name
            DocumentReference userCartDocRef = cartCollectionRef.document(email);

            // Create a reference to the "Products" collection within the user's cart document
            CollectionReference productsCollectionRef = userCartDocRef.collection("Products");

            // Create a document reference with the product name as the document name
            DocumentReference productDocRef = productsCollectionRef.document(Name);

            // Save the data in Firestore
            String productName = Name;
            String imageUrl = Image;
            String price = Price;

            // Create a map to store the product data
            Map<String, Object> productData = new HashMap<>();
            productData.put("imageUrl", imageUrl);
            productData.put("price", price);
            productData.put("name", productName);
            productData.put("desc",desc);

            // Set the product data in the Firestore document
            productDocRef.set(productData)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d("entry", "entry successful");
                            Toast.makeText(ac, "Item added to wishlist!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("entry", "entry unsuccessful", e);
                        }
                    });
        }catch (Exception e){
            Log.e("exception",e.toString());
        }


    }

}
