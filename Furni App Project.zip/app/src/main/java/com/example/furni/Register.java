package com.example.furni;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.hbb20.CountryCodePicker;

import java.util.Calendar;

public class Register extends AppCompatActivity {
    ImageButton back; // for back navigation
    EditText username,email,password,confirm_password,name,phone;
    CountryCodePicker ccp;
    String gender;
    DatePicker datePicker;
    Button next_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        back = findViewById(R.id.backbtn);
        username = findViewById(R.id.username);
        email= findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirm_password = findViewById(R.id.confirm_password);
        name = findViewById( R.id.name);
        ccp = findViewById(R.id.country_code_picker);
        phone = findViewById(R.id.phone);
        Spinner spinner = (Spinner) findViewById(R.id.gender_spinner);
        datePicker = findViewById(R.id.age_picker);
        next_btn = findViewById(R.id.next_btn);


        //for back navigation (back traces the intent stack)
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                finish();
            }
        });

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.genders_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Set an OnItemSelectedListener to the spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Retrieve the selected item
                gender = parentView.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing here if nothing is selected
            }
        });

        next_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int day = datePicker.getDayOfMonth();
                int month = datePicker.getMonth();
                int year = datePicker.getYear();
                String username_text = username.getText().toString();
                String email_text = email.getText().toString().trim();
                String password_text= password.getText().toString();
                String confirm_password_text = confirm_password.getText().toString();
                String name_text = name.getText().toString();
                String phone_text = ccp.getSelectedCountryCode() + phone.getText().toString();
                String phonenumber_text = phone.getText().toString();
                String _date = day + "/" + month + "/" + year;

                if(username_text.isEmpty()||email_text.isEmpty()||password_text.isEmpty()||name_text.isEmpty()||phone_text.isEmpty()||_date.isEmpty()||phonenumber_text.isEmpty())
                {
                    Toast.makeText(Register.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }else{
                    if(password_text.equals(confirm_password_text)){
                        System.out.println("password "+password_text+" confirm password "+confirm_password_text);
                        Intent i = new Intent(Register.this, Register2.class);
                        i.putExtra("fullName", name_text);
                        i.putExtra("date", _date);
                        i.putExtra("gender", gender);
                        i.putExtra("username",username_text);
                        i.putExtra("email",email_text);
                        i.putExtra("password",password_text);
                        i.putExtra("phone",phone_text);
                        startActivity(i);
                    }else{
                        System.out.println("password "+password_text+" confirm password "+confirm_password_text);
                        Toast.makeText(Register.this, "Passwords doesn't match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


    }

    private boolean validateAge() {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        int userAge = datePicker.getYear();
        int isAgeValid = currentYear - userAge;

        if (isAgeValid < 14) {
            Toast.makeText(this, "You must be 18 years old", Toast.LENGTH_SHORT).show();
            return false;

        } else {
            return true;
        }

    }
}