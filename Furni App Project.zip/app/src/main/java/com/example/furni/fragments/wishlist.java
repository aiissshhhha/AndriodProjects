package com.example.furni.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.furni.Adapters.CartAdapter;
import com.example.furni.Adapters.FirestoreUtils;
import com.example.furni.Adapters.Products;
import com.example.furni.Adapters.checkoutProducts;
import com.example.furni.Adapters.data_uploader;
import com.example.furni.Adapters.wishAdapter;
import com.example.furni.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class wishlist extends Fragment implements wishAdapter.OnRemoveButtonClickListener, wishAdapter.OnCartButtonClickListener{
    View v;
    RecyclerView recyclerView;
    private FirebaseFirestore firestore;
    private wishAdapter wishAdapter;
    TextView empty;
    com.example.furni.Adapters.data_uploader data_uploader = new data_uploader();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v= inflater.inflate(R.layout.fragment_wishlist, container, false);

        recyclerView = v.findViewById(R.id.wishlist_recyclerview);
        empty = v.findViewById(R.id.empty);
        firestore = FirebaseFirestore.getInstance();

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        wishAdapter = new wishAdapter(new ArrayList<>());
        recyclerView.setAdapter(wishAdapter);
        wishAdapter.setOnRemoveButtonClickListener(this);
        wishAdapter.setOnCartButtonClickListener(this);

        fetchProductsFromFirestore();
        return v;
    }

    private void fetchProductsFromFirestore() {
        String documentName = "";
        String email;
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        if (guest){
            SharedPreferences guestIdPref = requireContext().getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            documentName=id;
        }else {
            FirestoreUtils firestoreUtils = new FirestoreUtils();
            email = firestoreUtils.getCurrentUserEmail();
            documentName = email;
        }

        firestore.collection("wishlist")
                .document(documentName)
                .collection("Products")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<Products> productList = new ArrayList<>();

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String imageUrl = document.getString("imageUrl");
                            String name = document.getString("name");
                            String price = document.getString("price");
                            String desc = document.getString("desc");
                            String cat = document.getString("category");

                            Products product = new Products(imageUrl, name, price,cat, desc);

                            productList.add(product);
                        }
                        wishAdapter.setProductsList(productList);
                        if(productList.isEmpty()){
                            empty.setVisibility(View.VISIBLE);
                            empty.setText("Wishlist is Empty");
                        }
                    } else {
                        Log.d("Firestore", "Error getting products: ", task.getException());
                    }
                });
    }

    public void onRemoveButtonClick(int position, String name, String imageUrl, String price, String desc) {
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirestoreUtils email_getter = new FirestoreUtils();
        String documentName = name;
        String userEmail ="";
        if (guest) {
            SharedPreferences guestIdPref = requireContext().getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            userEmail=id;
        }
        else {
            userEmail = email_getter.getCurrentUserEmail();
        }

        documentName = name;

        firestore.collection("wishlist")
                .document(userEmail)
                .collection("Products")
                .document(documentName)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    // Document successfully deleted
                    Toast.makeText(getActivity(), "Removed Item", Toast.LENGTH_SHORT).show();
                    // Refresh the fragment by fetching the updated list of products
                    fetchProductsFromFirestore();
                })
                .addOnFailureListener(e -> {
                    // An error occurred while deleting the document
                    Toast.makeText(getActivity(), "Error removing Item", Toast.LENGTH_SHORT).show();
                });

    }

    @Override
    public void onCartButtonClick(int position, String name, String imageUrl, String price, String desc) {
        SharedPreferences sh = requireContext().getSharedPreferences("guest", MODE_PRIVATE);
        boolean s1 = sh.getBoolean("guest", false);
        String priceWithoutPoundSign = price.replace("£", "").trim();
        data_uploader.addToCart(desc,imageUrl,name,priceWithoutPoundSign,requireActivity(),s1);
        onRemoveButtonClick(position,name,imageUrl,priceWithoutPoundSign,desc);
        Log.d("data",name+"\n"+imageUrl+"\n"+price);
    }
}