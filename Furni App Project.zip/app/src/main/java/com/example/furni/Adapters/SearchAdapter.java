package com.example.furni.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.furni.R;

import java.util.List;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.SearchViewHolder> {
    private List<SearchData> searchResults;
    private Context context;

    private OnCartButtonClickListener cartButtonClickListener;
    private OnWishButtonClickListener wishButtonClickListener;

    public SearchAdapter(List<SearchData> searchResults, Context context) {
        this.searchResults = searchResults;
        this.context = context;
    }

    public interface OnCartButtonClickListener {
        void onCartButtonClick(int position, String name, String imageUrl, String price, String desc);
    }
    public interface OnWishButtonClickListener {
        void OnWishButtonClick(int position, String name, String imageUrl, String price, String desc);
    }

    public void setOnCartButtonClickListener(OnCartButtonClickListener listener) {
        this.cartButtonClickListener = listener;
    }

    public void setOnWishButtonClickListener(OnWishButtonClickListener listener) {
        this.wishButtonClickListener = listener;
    }

    @NonNull
    @Override
    public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder holder, int position) {
        SearchData searchData = searchResults.get(position);

        // Set data to views
        holder.titleTextView.setText(searchData.getTitle());
        holder.descriptionTextView.setText(searchData.getDescription());
        holder.priceTextView.setText("£ " + searchData.getPrice());

        // Load image using Glide library
        Glide.with(context)
                .load(searchData.getImageUrl())
                .into(holder.imageView);

        // Set click listeners for Cart and Wishlist buttons
        holder.wishlist_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (wishButtonClickListener != null) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        wishButtonClickListener.OnWishButtonClick(adapterPosition, searchData.getTitle(), searchData.getImageUrl(), searchData.getPrice(),searchData.getDescription());
                    }
                }
            }
        });

        holder.cart_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cartButtonClickListener != null) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        cartButtonClickListener.onCartButtonClick(adapterPosition, searchData.getTitle(), searchData.getImageUrl(), searchData.getPrice(),searchData.getDescription());
                    }
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return searchResults.size();
    }

    public void addResults(List<SearchData> newResults) {
        searchResults.addAll(newResults);
        notifyDataSetChanged();
    }

    public void clear() {
        searchResults.clear();
        notifyDataSetChanged();
    }

    public class SearchViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView titleTextView;
        TextView descriptionTextView;
        TextView priceTextView;
        Button cart_btn;
        ImageButton wishlist_btn;

        public SearchViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.image);
            titleTextView = itemView.findViewById(R.id.title);
            descriptionTextView = itemView.findViewById(R.id.desc);
            priceTextView = itemView.findViewById(R.id.price);
            cart_btn = itemView.findViewById(R.id.cart_btn);
            wishlist_btn = itemView.findViewById(R.id.wishlist_btn);

            cart_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (cartButtonClickListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            String itemName = titleTextView.getText().toString();
                            String itemImageUrl = searchResults.get(position).getImageUrl();
                            String itemPrice = priceTextView.getText().toString();
                            String desc1 = descriptionTextView.getText().toString();
                            cartButtonClickListener.onCartButtonClick(position, itemName, itemImageUrl, itemPrice,desc1);
                        }
                    }
                }
            });
            wishlist_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (wishButtonClickListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            String itemName = titleTextView.getText().toString();
                            String itemImageUrl = searchResults.get(position).getImageUrl();
                            String itemPrice = priceTextView.getText().toString();
                            String desc1 = descriptionTextView.getText().toString();
                            wishButtonClickListener.OnWishButtonClick(position, itemName, itemImageUrl, itemPrice,desc1);
                        }
                    }
                }
            });
        }
    }
}
