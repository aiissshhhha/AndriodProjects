package com.example.furni.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.furni.R;

import java.util.List;

public class category_adapter extends RecyclerView.Adapter<category_adapter.MyViewHolder> {
    List<Products> products;
    private OnCartButtonClickListener cartButtonClickListener;
    private OnWishButtonClickListener wishButtonClickListener;
    private OnCardClickListener cardClickListener;
    public category_adapter(List<Products> products) {
        this.products = products;
    }

    public interface OnCartButtonClickListener {
        void onCartButtonClick(int position, String name, String imageUrl, String price, String desc);
    }
    public interface OnWishButtonClickListener {
        void OnWishButtonClick(int position, String name, String imageUrl, String price, String desc);
    }
    public interface OnCardClickListener {
        void onCardClick(int position,String category, String name, String url,String price, String description);
    }

    public void setOnCardClickListener(OnCardClickListener listener) {
        this.cardClickListener = listener;
    }

    public void setOnCartButtonClickListener(OnCartButtonClickListener listener) {
        this.cartButtonClickListener = listener;
    }

    public void setOnWishButtonClickListener(OnWishButtonClickListener listener) {
        this.wishButtonClickListener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Products product = products.get(position);

        // Retrieve the data from the product object
        String name = product.getName();
        String price = product.getPrice();
        String finalprice = "£ "+price;
        String imageUrl = product.getImageUrl();
        String category = product.getCategory();
        String description = product.getDescription();


        // Set the data to the corresponding views in the ViewHolder
        holder.name.setText(name);
        holder.price.setText(finalprice);
        holder.desc.setText(description);
        // Load and display the image using Glide
        Glide.with(holder.itemView)
                .load(imageUrl)
                .into(holder.imageView);

        holder.cart_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cartButtonClickListener != null) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        cartButtonClickListener.onCartButtonClick(adapterPosition, name, imageUrl, price, description);
                    }
                }
            }
        });

        holder.wishlist_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (wishButtonClickListener != null) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        wishButtonClickListener.OnWishButtonClick(adapterPosition, name, imageUrl, price,description);
                    }
                }
            }
        });

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cardClickListener != null) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        cardClickListener.onCardClick(adapterPosition,category, name, imageUrl, price, description);
                    }
                }
            }
        });
    }

    public void setProductsList(List<Products> productsList) {
        this.products = productsList;
        notifyDataSetChanged();
    }


    @Override
    public int getItemCount() {
        return products.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView price;
        ImageView imageView;
        Button cart_btn;
        CardView cardView;
        TextView desc;
        ImageButton wishlist_btn;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.title);
            price = itemView.findViewById(R.id.price);
            imageView = itemView.findViewById(R.id.image);
            cart_btn = itemView.findViewById(R.id.cart_btn);
            cardView = itemView.findViewById(R.id.product);
            desc = itemView.findViewById(R.id.desc);
            wishlist_btn = itemView.findViewById(R.id.wishlist_btn);

            cart_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (cartButtonClickListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            String itemName = name.getText().toString();
                            String itemImageUrl = products.get(position).getImageUrl();
                            String itemPrice = price.getText().toString();
                            String desc1 = desc.getText().toString();
                            cartButtonClickListener.onCartButtonClick(position, itemName, itemImageUrl, itemPrice,desc1);
                        }
                    }
                }
            });
            wishlist_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (wishButtonClickListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            String itemName = name.getText().toString();
                            String itemImageUrl = products.get(position).getImageUrl();
                            String itemPrice = price.getText().toString();
                            String desc1 = desc.getText().toString();
                            wishButtonClickListener.OnWishButtonClick(position, itemName, itemImageUrl, itemPrice,desc1);
                        }
                    }
                }
            });
        }
    }

}


