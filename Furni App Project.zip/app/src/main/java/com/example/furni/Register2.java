package com.example.furni;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class Register2 extends AppCompatActivity {
    ImageButton back; // for back navigation
    EditText expiryEditText,card_name,card_number,zip_code;
    Button signup;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register2);

        back = findViewById(R.id.backbtn);
        expiryEditText = findViewById(R.id.expiry);
        card_name=findViewById(R.id.name_card);
        card_number=findViewById(R.id.card_number);
        zip_code=findViewById(R.id.zip);
        signup=findViewById(R.id.signup_btn);
        String username = getIntent().getStringExtra("username");
        String email = getIntent().getStringExtra("email");
        String password = getIntent().getStringExtra("password");
        String phone = getIntent().getStringExtra("phone");
        String name = getIntent().getStringExtra("fullName");
        String gender = getIntent().getStringExtra("gender");
        String date = getIntent().getStringExtra("date");
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Set DigitsKeyListener to allow only digits and "/"
        expiryEditText.setKeyListener(DigitsKeyListener.getInstance("0123456789/"));

        // Set InputFilter to limit the length and format the input
        expiryEditText.setFilters(new InputFilter[]{new ExpiryDateInputFilter()});

        // Add TextWatcher to format the input
        expiryEditText.addTextChangedListener(new ExpiryDateTextWatcher());

        // for back navigation (back traces the intent stack)
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                finish();
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform signup with email and password
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(Register2.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign up success


                                    // Save additional user details to Firestore
                                    saveUserDetails(email, username, phone, date, gender, name);

                                    // You can add additional logic or navigate to another activity here.
                                } else {
                                    // If sign up fails, display a message to the user.
                                    Toast.makeText(Register2.this, "Signup failed. " + task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    private void saveUserDetails(String email, String username, String phone, String dob, String gender, String name) {
        // Add user details to Firestore under "users" collection
        User user = new User(username, phone, dob, gender, name);

        db.collection("users")
                .document(email) // Use email as the document ID
                .set(user)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // User details saved successfully
                            Toast.makeText(Register2.this, "Signup successful.", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(Register2.this, HomeScreen.class);
                            startActivity(i);
                        } else {
                            // If saving fails, display a message to the user.
                            Toast.makeText(Register2.this, "Failed to save user details to Firestore.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private class ExpiryDateInputFilter implements InputFilter {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            // Limit the length to 5 characters (MM/YY format)
            if (dest.length() == 5) {
                return "";
            }

            // Allow only digits and "/"
            for (int i = start; i < end; i++) {
                char character = source.charAt(i);
                if (!Character.isDigit(character) && character != '/') {
                    return "";
                }
            }

            return null; // Accept the input
        }
    }

    private class ExpiryDateTextWatcher implements TextWatcher {
        private static final int MAX_LENGTH = 5;

        @Override
        public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {
            // No action needed
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            // No action needed
        }

        @Override
        public void afterTextChanged(Editable editable) {
            // Format the input as MM/YY
            if (editable.length() == 1 && Character.isDigit(editable.charAt(0))) {
                editable.insert(0, "0");
            } else if (editable.length() == 2 && editable.charAt(1) != '/') {
                editable.insert(2, "/");
            } else if (editable.length() > MAX_LENGTH) {
                editable.delete(MAX_LENGTH, editable.length());
            }
        }
    }
}
