package com.example.furni;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.furni.Adapters.Products;
import com.example.furni.Adapters.SearchAdapter;
import com.example.furni.Adapters.SearchData;
import com.example.furni.Adapters.data_uploader;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchActivity extends AppCompatActivity implements SearchAdapter.OnCartButtonClickListener, SearchAdapter.OnWishButtonClickListener{
    ImageButton back;
    RecyclerView recyclerView;
    SearchAdapter searchAdapter;
    String query;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Intent i = getIntent();
        query = i.getStringExtra("query");
        Log.e("query",query);

        back = findViewById(R.id.backbtn);
        recyclerView = findViewById(R.id.search_recycler_view);

        // Setup the RecyclerView with an empty list initially
        List<SearchData> searchResults = new ArrayList<>();
        searchAdapter = new SearchAdapter(searchResults, this);
        searchAdapter.setOnCartButtonClickListener(this);
        searchAdapter.setOnWishButtonClickListener(this);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(searchAdapter);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                finish();
            }
        });

        performSearch();
    }

    public void performSearch() {
        String searchTerm = query;

        if (!searchTerm.isEmpty()) {
            // Clear previous search results
            searchAdapter.clear();

            // Perform search in each collection
            searchInCollection("beds", searchTerm);
            searchInCollection("chairs", searchTerm);
            searchInCollection("sofas", searchTerm);
        } else {
            Toast.makeText(this, "Please enter a search term", Toast.LENGTH_SHORT).show();
        }
    }

    private void searchInCollection(String collectionName, String searchTerm) {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();

        // Corrected code
        firestore.collection(collectionName)
                .whereArrayContains("keywords", searchTerm.toLowerCase())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            List<SearchData> results = new ArrayList<>();
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                // Extract relevant data from the document
                                String title = document.getString("title");
                                String description = document.getString("desc");
                                String imageUrl = document.getString("image");
                                String price = document.getString("price");

                                // Create a SearchData object and add it to the results
                                SearchData searchData = new SearchData(title, description, imageUrl, price);
                                results.add(searchData);
                            }

                            // Update the adapter with search results
                            searchAdapter.addResults(results);
                        } else {
                            // Handle errors
                            Toast.makeText(SearchActivity.this, "Error searching in " + collectionName, Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }

    @Override
    public void onCartButtonClick(int position, String name, String imageUrl, String price, String desc) {
        SharedPreferences sh = getSharedPreferences("guest", MODE_PRIVATE);
        boolean s1 = sh.getBoolean("guest", false);
        String email = "";
        if (s1) {
            SharedPreferences guestIdPref = getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            email = id;
            Log.e("email","guest id "+email);
        } else {
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                email = currentUser.getEmail();
            }
        }

        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();

            // Create a reference to the "cart" collection
            CollectionReference cartCollectionRef = db.collection("cart");

            // Create a document reference with the user's email as the document name
            DocumentReference userCartDocRef = cartCollectionRef.document(email);

            // Create a reference to the "Products" collection within the user's cart document
            CollectionReference productsCollectionRef = userCartDocRef.collection("Products");

            // Create a document reference with the product name as the document name
            DocumentReference productDocRef = productsCollectionRef.document(name);

            // Create a map to store the product data
            Map<String, Object> productData = new HashMap<>();
            productData.put("imageUrl", imageUrl);
            productData.put("price", price);
            productData.put("name", name);
            productData.put("desc",desc);

            // Set the product data in the Firestore document
            productDocRef.set(productData)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d("entry", "entry successful");
                            Toast.makeText(SearchActivity.this, "Item added to cart!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("entry", "entry unsuccessful", e);
                        }
                    });
        }catch (Exception e){
            Log.e("exception",e.toString());
        }
    }

    @Override
    public void OnWishButtonClick(int position, String name, String imageUrl, String price,String desc) {
        SharedPreferences sh = getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        String email = "";
        if (guest) {
            SharedPreferences guestIdPref = getSharedPreferences("guestid", MODE_PRIVATE);
            String id = guestIdPref.getString("id", "");
            email = id;
            Log.e("email","guest id "+email);
        } else {
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                email = currentUser.getEmail();
            }
        }

        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();

            // Create a reference to the "cart" collection
            CollectionReference cartCollectionRef = db.collection("wishlist");

            // Create a document reference with the user's email as the document name
            DocumentReference userCartDocRef = cartCollectionRef.document(email);

            // Create a reference to the "Products" collection within the user's cart document
            CollectionReference productsCollectionRef = userCartDocRef.collection("Products");

            // Create a document reference with the product name as the document name
            DocumentReference productDocRef = productsCollectionRef.document(name);

            // Create a map to store the product data
            Map<String, Object> productData = new HashMap<>();
            productData.put("imageUrl", imageUrl);
            productData.put("price", price);
            productData.put("name", name);
            productData.put("desc",desc);

            // Set the product data in the Firestore document
            productDocRef.set(productData)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d("entry", "entry successful");
                            Toast.makeText(SearchActivity.this, "Item added to wishlist!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.e("entry", "entry unsuccessful", e);
                        }
                    });
        }catch (Exception e){
            Log.e("exception",e.toString());
        }
    }
}