package com.example.furni;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.UUID;

public class Login extends AppCompatActivity {
    ImageButton back; // for back navigation
    EditText email;
    EditText password;
    Button login_btn;
    FirebaseAuth mAuth;
    ProgressBar progressBar;
    TextView forgotbtn; // for navigating to reset password activity
    TextView guest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        //initializing the data variables
        back = findViewById(R.id.backbtn);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login_btn = findViewById(R.id.log_in_btn);
        mAuth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.progressBar);
        forgotbtn = findViewById(R.id.forgot_btn);
        guest = findViewById(R.id.guest);

        //for back navigation (back traces the intent stack)
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                finish();
            }
        });

        // for navigating to reset password activity
        forgotbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gotoReset = new Intent(Login.this, reset_password.class);
                startActivity(gotoReset);
            }
        });

        guest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean guest = true;
                String guestid = generateUniqueId();
                Log.e("from login","guest id is "+ guestid);
                SharedPreferences sharedPreferences1 = getSharedPreferences("guestid", MODE_PRIVATE);
                SharedPreferences.Editor guestidedit = sharedPreferences1.edit();
                SharedPreferences sharedPreferences = getSharedPreferences("guest", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                myEdit.putBoolean("guest",guest);
                guestidedit.putString("id",guestid);
                myEdit.apply();
                guestidedit.apply();
                Intent gotoReset = new Intent(Login.this, HomeScreen.class);
                startActivity(gotoReset);
            }
        });

        //for logging in
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //extracting data
                String Email = email.getText().toString().trim();
                String Password = password.getText().toString();

                // Perform validation
                boolean isValid = true;

                if (Email.isEmpty()) {
                    email.setBackground(ContextCompat.getDrawable(Login.this, R.drawable.custom_shape_error));
                    isValid = false;
                } else {
                    email.setBackground(ContextCompat.getDrawable(Login.this, R.drawable.custom_shape));
                }

                if (Password.isEmpty()) {
                    password.setBackground(ContextCompat.getDrawable(Login.this, R.drawable.custom_shape_error));
                    isValid = false;
                } else {
                    password.setBackground(ContextCompat.getDrawable(Login.this, R.drawable.custom_shape));
                }

                if (!isValid) {
                    Toast.makeText(Login.this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                //log in method
                setLogin(Email,Password);
            }
        });
    }

    public static String generateUniqueId() {
        // Get a timestamp to ensure uniqueness
        long timestamp = System.currentTimeMillis();

        // Generate a random component to reduce the chance of collision
        String randomComponent = UUID.randomUUID().toString();

        // Combine timestamp and random component to create a unique ID
        String uniqueId = timestamp + "_" + randomComponent;

        return uniqueId;
    }

    public void gotoRegister(View v){
        Intent gotoRegister = new Intent(Login.this, Register.class);
        startActivity(gotoRegister);
    }

    private void setLogin(String email, String password){
        progressBar.setVisibility(View.VISIBLE); // Show the ProgressBar before creating the user
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("msg", "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            progressBar.setVisibility(View.GONE); // Hide the ProgressBar after data storage is complete
                            SharedPreferences sharedPreferences = getSharedPreferences("guest", MODE_PRIVATE);
                            SharedPreferences.Editor myEdit = sharedPreferences.edit();
                            myEdit.putBoolean("guest",false);
                            myEdit.apply();
                            Intent goToMain = new Intent(Login.this,HomeScreen.class);
                            startActivity(goToMain);
                            finish();
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("msg", "signInWithEmail:failure", task.getException());
                            Toast.makeText(Login.this, "LogIn failed.",
                                    Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE); // Hide the ProgressBar after data storage is complete
                        }
                    }
                });
    }
}