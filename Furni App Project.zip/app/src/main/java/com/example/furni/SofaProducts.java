package com.example.furni;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SofaProducts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sofa_products);
    }
}