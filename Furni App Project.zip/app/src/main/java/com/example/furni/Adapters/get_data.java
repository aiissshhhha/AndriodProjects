package com.example.furni.Adapters;

import android.text.TextUtils;
import android.util.Log;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class get_data {
    public CompletableFuture<List<Products>> getAllProductsData(String calling, String activity) {
        CompletableFuture<List<Products>> combinedFuture = new CompletableFuture<>();

        switch(calling){
            case "furniture":
                CompletableFuture<List<Products>> bedData = getData("tables");
                CompletableFuture<List<Products>> dineData = getData("dining");
                CompletableFuture<List<Products>> sofaData = getData("sofas");
                // Combine all CompletableFuture instances into a single CompletableFuture
                combinedFuture = CompletableFuture.allOf(
                        bedData,
                        dineData,
                        sofaData
                ).thenApply(ignored ->
                        combineLists(
                                activity,
                                bedData.join(),
                                dineData.join(),
                                sofaData.join()
                        )
                );
                break;
            case "all":
                CompletableFuture<List<Products>> shoesData = getData("shoes");
                CompletableFuture<List<Products>> shirtsData = getData("shirts");
                CompletableFuture<List<Products>> tablesData = getData("tables");
                CompletableFuture<List<Products>> diningData = getData("dining");
                CompletableFuture<List<Products>> sofasData = getData("sofas");
                CompletableFuture<List<Products>> kitchenData = getData("kitchen");
                CompletableFuture<List<Products>> laptopsData = getData("laptops");

                // Combine all CompletableFuture instances into a single CompletableFuture
                combinedFuture = CompletableFuture.allOf(
                        laptopsData,
                        shoesData,
                        shirtsData,
                        tablesData,
                        diningData,
                        sofasData,
                        kitchenData
                ).thenApply(ignored ->
                        combineLists(
                                activity,
                                kitchenData.join(),
                                laptopsData.join(),
                                shirtsData.join(),
                                tablesData.join(),
                                diningData.join(),
                                sofasData.join(),
                                shoesData.join()

                        )
                );

                break;
            default:
                break;
        }

        return combinedFuture;
    }

    private List<Products> combineLists(String calling, List<Products>... lists) {
        List<Products> combinedList = new ArrayList<>();
        int count = 0;
        if(calling=="home"){
            for (List<Products> list : lists) {
                int maxItems = Math.min(list.size(), 100); // Limit to n items from each list
                for (int i = 0; i < maxItems; i++) {
                    combinedList.add(list.get(i));
                    count++;
                    if (count >= 100) {
                        break; // Break the loop if we have reached the limit
                    }
                }
            }
        }else if(calling=="search"){
            for (List<Products> list : lists) {
                for (int i = 0; i < list.size(); i++) {
                    combinedList.add(list.get(i));
                    count++;
                }
            }
        }
        return combinedList;
    }

    public CompletableFuture<List<Products>> getData(String calling) {
        String documentName="",subCollection="";
        FirestoreUtils firestoreUtils = new FirestoreUtils();

        String email = firestoreUtils.getCurrentUserEmail();

        switch(calling){
            case "laptops":
                documentName = "laptops";
                subCollection = "all";
                break;
            case "shoes":
                documentName = "shoes";
                subCollection = "all";
                break;
            case "shirts":
                documentName = "shirts";
                subCollection = "all";
                break;
            case "tables":
                documentName = "furniture";
                subCollection = "tables";
                break;
            case "sofas":
                documentName = "furniture";
                subCollection = "sofas";
                break;
            case "dining":
                documentName = "furniture";
                subCollection = "dining";
                break;
            case "kitchen":
                documentName = "kitchen";
                subCollection = "all";
                break;
            case "cart":
                documentName = email;
                subCollection = "products";
                break;
            default:
                break;
        }

        String doc = documentName;

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference laptopsRef = db.collection("products").document(documentName).collection(subCollection);
        List<Products> productList = new ArrayList<>();

        final CompletableFuture<List<Products>> completableFuture = new CompletableFuture<>();
        laptopsRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {

                for (QueryDocumentSnapshot document : task.getResult()) {
                    String imageUrl = document.getString("imageURL");
                    String name = document.getString("name");
                    String price = document.getString("price");
                    String cat = document.getString("category");

                    if(!doc.equals("furniture")){
                        // Fetch the array as a List<String> from Firestore
                        List<String> desc = (List<String>) document.get("keyFeatures");
                        String description = desc != null ? TextUtils.join(", ", desc) : "";

                        Products product = new Products(imageUrl, name, price,cat, description);
                        productList.add(product);
                    }else{
                        String description = document.getString("description");
                        String dimensions = document.getString("dimensions");

                        Products product = new Products(imageUrl, name, price,cat, description);
                        productList.add(product);
                    }
                }
                completableFuture.complete(productList);
            } else {
                Log.d("task failed", "failed failed failed");
                completableFuture.completeExceptionally(task.getException());
            }
        });
        return completableFuture;
    }
}
