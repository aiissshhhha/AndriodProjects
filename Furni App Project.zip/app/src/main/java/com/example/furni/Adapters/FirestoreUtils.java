package com.example.furni.Adapters;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class FirestoreUtils {
    private FirebaseAuth auth;

    public String getCurrentUserEmail() {
        auth = FirebaseAuth.getInstance();
        String userEmail = null;
        FirebaseUser currentUser = auth.getCurrentUser();

        if (currentUser != null) {
            userEmail = currentUser.getEmail();
        } else {
            Log.d("Data Getter", "No current user found");
        }
        return userEmail;
    }
}