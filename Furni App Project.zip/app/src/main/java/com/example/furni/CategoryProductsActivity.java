package com.example.furni;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.furni.Adapters.CategoriesProductsAdapter;
import com.example.furni.Adapters.Products;
import com.example.furni.Adapters.data_uploader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CategoryProductsActivity extends AppCompatActivity implements com.example.furni.Adapters.CategoriesProductsAdapter.OnCartButtonClickListener, com.example.furni.Adapters.CategoriesProductsAdapter.OnCardClickListener,com.example.furni.Adapters.CategoriesProductsAdapter.OnWishButtonClickListener{
    ImageButton back; // for back navigation
    com.example.furni.Adapters.data_uploader data_uploader = new data_uploader();
    private RecyclerView.LayoutManager layoutManager;
    CategoriesProductsAdapter categoriesProductsAdapter;
    private RecyclerView recyclerView;
    private List<Products> combined = new ArrayList<>();
    TextView category;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chair_products);

        Intent i = getIntent();
        String cat = i.getStringExtra("cat");

        data_fetcher data = new data_fetcher();
        back = findViewById(R.id.backbtn);
        recyclerView = findViewById(R.id.products_recyclerview);
        layoutManager = new GridLayoutManager(CategoryProductsActivity.this, 2);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setLayoutManager(layoutManager);
        category = findViewById(R.id.cat);

        category.setText(cat);

        if(cat.equals("Chairs")){
            // Fetch initial data and populate RecyclerView
            data.fetchchairsdata().thenAccept(combinedList -> {
                combined.addAll(combinedList);
                // Randomize the combinedList
                Collections.shuffle(combined);
                Collections.shuffle(combined);
                categoriesProductsAdapter = new CategoriesProductsAdapter(combined);
                recyclerView.setAdapter(categoriesProductsAdapter);
                categoriesProductsAdapter.setOnCartButtonClickListener(this);
                categoriesProductsAdapter.setOnCardClickListener(this);
                categoriesProductsAdapter.setOnWishButtonClickListener(this);
            }).exceptionally(throwable -> {
                Log.e("getData", "Error fetching data", throwable);
                return null;
            });
        }else if (cat.equals("Beds")){
            // Fetch initial data and populate RecyclerView
            data.fetchbedsdata().thenAccept(combinedList -> {
                combined.addAll(combinedList);
                // Randomize the combinedList
                Collections.shuffle(combined);
                Collections.shuffle(combined);
                categoriesProductsAdapter = new CategoriesProductsAdapter(combined);
                recyclerView.setAdapter(categoriesProductsAdapter);
                categoriesProductsAdapter.setOnCartButtonClickListener(this);
                categoriesProductsAdapter.setOnCardClickListener(this);
                categoriesProductsAdapter.setOnWishButtonClickListener(this);
            }).exceptionally(throwable -> {
                Log.e("getData", "Error fetching data", throwable);
                return null;
            });
        } else if (cat.equals("Sofas")) {
            // Fetch initial data and populate RecyclerView
            data.fetchsofasdata().thenAccept(combinedList -> {
                combined.addAll(combinedList);
                // Randomize the combinedList
                Collections.shuffle(combined);
                Collections.shuffle(combined);
                categoriesProductsAdapter = new CategoriesProductsAdapter(combined);
                recyclerView.setAdapter(categoriesProductsAdapter);
                categoriesProductsAdapter.setOnCartButtonClickListener(this);
                categoriesProductsAdapter.setOnCardClickListener(this);
                categoriesProductsAdapter.setOnWishButtonClickListener(this);
            }).exceptionally(throwable -> {
                Log.e("getData", "Error fetching data", throwable);
                return null;
            });
        }



        //for back navigation (back traces the intent stack)
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                finish();
            }
        });
    }

    @Override
    public void onCartButtonClick(int position, String name, String imageUrl, String price, String desc) {
        SharedPreferences sh = getSharedPreferences("guest", MODE_PRIVATE);
        boolean s1 = sh.getBoolean("guest", false);
        data_uploader.addToCart(desc,imageUrl,name,price, CategoryProductsActivity.this,s1);
        Log.d("data",name+"\n"+imageUrl+"\n"+price);
    }

    @Override
    public void onCardClick(int position,String category, String name, String url,String price, String description) {
        if(category.equals("laptops")||category.equals("shoes")||category.equals("kitchen")||category.equals("shirts")){
            Intent i = new Intent(CategoryProductsActivity.this, Login.class);
            i.putExtra("name",name);
            i.putExtra("price",price);
            i.putExtra("url",url);
            i.putExtra("desc",description);
            startActivity(i);
        }

    }

    @Override
    public void OnWishButtonClick(int position, String name, String imageUrl, String price,String desc) {
        SharedPreferences sh = getSharedPreferences("guest", MODE_PRIVATE);
        boolean guest = sh.getBoolean("guest", false);
        data_uploader.addToWishlist(desc,imageUrl,name,price, CategoryProductsActivity.this,guest);
    }
}