package com.example.furni;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class reset_password extends AppCompatActivity {
    ImageButton back; // for back navigation
    EditText email;
    Button send_email; //for logging in
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);


        email = findViewById(R.id.email);
        send_email = findViewById(R.id.reset_btn);
        back = findViewById(R.id.backbtn);

        send_email.setOnClickListener(view -> {
            String Email = email.getText().toString().trim();

            // Perform validation
            boolean isValid = true;

            if (Email.isEmpty()) {
                email.setBackground(ContextCompat.getDrawable(reset_password.this, R.drawable.custom_shape_error));
                isValid = false;
            } else {
                email.setBackground(ContextCompat.getDrawable(reset_password.this, R.drawable.custom_shape));
            }

            if (!isValid) {
                Toast.makeText(reset_password.this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Send password reset email
            FirebaseAuth auth = FirebaseAuth.getInstance();
            auth.sendPasswordResetEmail(Email)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            showResetPasswordDialog();
                        } else {
                            Toast.makeText(reset_password.this, "User not Registered", Toast.LENGTH_SHORT).show();
                        }
                    });

        });

        //for back navigation (back traces the intent stack)
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                finish();
            }
        });
    }

    private void showResetPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Reset Password Email Sent")
                .setMessage("Reset Password Email has been sent to your registered email. Please check the spam folder if you cannot find the email.")
                .setPositiveButton("OK", null)
                .show();
    }
}