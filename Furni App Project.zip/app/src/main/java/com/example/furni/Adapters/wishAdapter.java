package com.example.furni.Adapters;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.furni.R;

import java.util.List;

public class wishAdapter extends RecyclerView.Adapter<wishAdapter.CartViewHolder> {
    List<Products> productsList;
    private  OnRemoveButtonClickListener removeButtonClickListener;
    private OnCartButtonClickListener cartButtonClickListener;
    public wishAdapter(List<Products> productsList) {
        this.productsList = productsList;
    }

    public wishAdapter() {
    }

    public interface OnCartButtonClickListener {
        void onCartButtonClick(int position, String name, String imageUrl, String price, String desc);
    }
    public interface OnRemoveButtonClickListener {
        void onRemoveButtonClick(int position, String name, String imageUrl, String price, String desc);
    }

    public void setOnCartButtonClickListener(OnCartButtonClickListener listener) {
        this.cartButtonClickListener = listener;
    }
    public void setOnRemoveButtonClickListener(OnRemoveButtonClickListener listener) {
        this.removeButtonClickListener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wish, parent, false);
        return new CartViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        Products product = productsList.get(position);

        // Retrieve the data from the product object
        String name = product.getName();
        String price = "£ "+product.getPrice();
        String imageUrl = product.getImageUrl();
        String description = product.getDescription();
        Log.e("from cart speakng","name: "+name+" price: "+price);


        // Set the data to the corresponding views in the ViewHolder
        holder.name.setText(name);
        holder.price.setText(price);
        holder.desc.setText(description);
        // Load and display the image using Glide
        Glide.with(holder.itemView)
                .load(imageUrl)
                .into(holder.imageView);

        holder.remove_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (removeButtonClickListener != null) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        removeButtonClickListener.onRemoveButtonClick(adapterPosition, name, imageUrl, price, description);
                    }
                }
            }
        });

        holder.cart_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cartButtonClickListener != null) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        cartButtonClickListener.onCartButtonClick(adapterPosition, name, imageUrl, price, description);
                    }
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return productsList.size();
    }

    public void setProductsList(List<Products> productsList) {
        this.productsList = productsList;
        notifyDataSetChanged();
    }
    public class CartViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView price;
        ImageView imageView;
        ImageView remove_btn;
        TextView desc;
        Button cart_btn;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.title);
            price = itemView.findViewById(R.id.price);
            imageView = itemView.findViewById(R.id.image);
            remove_btn = itemView.findViewById(R.id.trash_btn);
            desc = itemView.findViewById(R.id.desc);
            cart_btn = itemView.findViewById(R.id.cart_btn);

            cart_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (cartButtonClickListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            String itemName = name.getText().toString();
                            String itemImageUrl = productsList.get(position).getImageUrl();
                            String itemPrice = price.getText().toString();
                            String desc1 = desc.getText().toString();
                            cartButtonClickListener.onCartButtonClick(position, itemName, itemImageUrl, itemPrice,desc1);
                        }
                    }
                }
            });

            remove_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (removeButtonClickListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            String itemName = name.getText().toString();
                            String itemImageUrl = productsList.get(position).getImageUrl();
                            String itemPrice = price.getText().toString();
                            String desc1 = desc.getText().toString();
                            removeButtonClickListener.onRemoveButtonClick(position, itemName, itemImageUrl, itemPrice, desc1);
                        }
                    }
                }
            });
        }
    }

}


